<html>
<head>
<script>
function showResult(str){
	if(str.length==0){
		document.getElementById("livesearch").innerHTML="";
		document.getElementById("livesearch").style.border="0px";
		return;
	}
	if(window.XMLHttpRequest){
		// Code for IE7+, Firefox, Chrome, Opera, Safari
		xmlhttp=new XMLHttpRequest();
	}
	else
	{//Code for IE6, IE5
	xmlhttp=new ActiveXobject("Microsoft.XMLHTTP");
	}
	xmlhttp.onreadystatechange=function(){
		if(xmlhttp.readyState==4 && xmlhttp.status==200){
			document.getElementById("livesearch").innerHTML=xmlhttp.responseText;
			document.getElementById("livesearch").style.border="1px solid #A5ACB2";
		}
	}
	xmlhttp.open("GET", "livesearch.php?q="+str,true);
	xmlhttp.send();
}
</script>
</head>
<body>
<form>
<h1>Search</h1>
<body bgcolor="grey">
 <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <h1><style="color:orange"></style>Please Search here : <input type="text" size="30" onKeyUp="showResult(this.value)"></h1>
  
<div id="livesearch"></div>
</form>
</body>
</html>