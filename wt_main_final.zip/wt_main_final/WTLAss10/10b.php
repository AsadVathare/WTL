<html>
<body>
<form method="POST">
Enter the possible palindorme number<input type="number" name="input"<br>
<input type="submit" name="submit">
</form>
</body>
</html>
<?php  
error_reporting(0);
function palindrome($n){ 
$number = $n;  
$input;
$sum = 0;  
while(floor($number)) {  
$rem = $number % 10;  
$sum = $sum * 10 + $rem;  
$number = $number/10;  
}  
return $sum;  
} 
$num = palindrome($input);  
if($input==$num){  
echo "$input is a Palindrome number";  
} else 
{  
echo "$input is not a Palindrome";  
}  
?>  