<!DOCTYPE html>
<?php 
require('connect.php'); 
?>
<html>

<head>
    <title>Student Result Page</title>
    <link rel="stylesheet" href="stylesheet1.css" type="text/css" />
    <link href='https://code.cdn.mozilla.net/fonts/fira.css' rel='stylesheet' />
    <link href="https://fonts.googleapis.com/css?family=Fira%20Code" rel='stylesheet' />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body>
    <table border="2" width="60%" align="center" valign="middle">
        <tr align="center">
            <td valign="bottom">
                <h1>Student Exam Results</h1>
            </td>
        </tr>
    </table>
    <table bgcolor="black" border="2" width="60%" align="center" celpadding="15px">
        <tr>
            <th>Seat No.</th>
            <th>Studnet Name</th>
            <th>DS Marks</th>
            <th>WT marks</th>
            <th>AI Marks</th>
            <th>Elective2 Marks</th>
            <th>Total</th>
            <th>Percent</th>
            <th>Grade</th>
        </tr>
        <?php
        $sql_query = "SELECT * FROM `data`";
        $result_set = mysqli_query($connection, $sql_query);
        if (mysqli_num_rows($result_set) > 0) {
            while ($row = mysqli_fetch_row($result_set)) {
        ?>
        <tr>
            <td>
                <?php echo $row[0]; ?>
            </td>
            <td>
                <?php echo $row[1]; ?>
            </td>
            <td>
                <?php echo $row[2]; ?>
            </td>
            <td>
                <?php echo $row[3]; ?>
            </td>
            <td>
                <?php echo $row[4]; ?>
            </td>
            <td>
                <?php echo $row[5]; ?>
            </td>
            <td>
                <?php echo $row[6]; ?>
            </td>
            <td>
                <?php echo $row[7]; ?>
            </td>
            <td>
                <?php echo $row[8]; ?>
            </td>
        </tr>
        <?php
            }
        } else {
        ?>
        <tr>
            <td colspan="9">No Data Found !</td>
        </tr>
        <?php
        }
        ?>
    </table>
</body>

</html>