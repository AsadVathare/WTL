function valid() {
    var fullname = document.getElementsByName("fname")[0].value;
    var fullname = document.getElementsByName("lname")[0].value;
    var email = document.getElementsByName("mail")[0].value;
    var mob = document.getElementsByName("mono")[0].value;
    var pswd = document.getElementsByName("pswd")[0].value;
    var rpswd = document.getElementsByName("rpswd")[0].value;
    var username = document.getElementsByName("uid")[0].value;

    if (uidvalidate(username)) {
        if (valname(fullname)) {
            if (valmob(mob)) {
                if (valemail(email)) {
                    if (valpass(pswd)) {
                        if (valrpass(pswd, rpswd)) {
                            alert("User Registered Successfully.");
                        }
                    }
                }
            }
        }
    }
}

function uidvalidate(uid) {
    var usernameRegex = /^[a-zA-Z0-9]+$/;
    if (uid.match(usernameRegex) && uid.length > 3 && uid.length < 25) {
        return true;
    }
    else {
        alert("Invalid username");
        return false;
    }
}

function valname(name) {
    var letters = /^[A-Za-z]+$/;
    if (name.match(letters))
        return true;
    else {
        alert("Name must have alphabet characters only.");
        return false;
    }
}

function valrpass(pswd, rpswd) {
    if (rpswd.length == 0) {
        alert("Confirm Password field empty.");
        return;
    }
    if (rpswd == pswd)
        return true;
    else {
        alert("Confirm Password doesn't Matched.");
        return false;
    }
}

function valpass(pswd) {
    if (pswd.length < 8) {
        alert("Error: Password must contain at least 8 characters!");
        return false;
    }
    re = /[0-9]/;
    if (!re.test(pswd)) {
        alert("Error: Password must contain at least one number (0-9)!");
        return false;
    }
    re = /[a-z]/;
    if (!re.test(pswd)) {
        alert("Error: Password must contain at least one lowercase letter (a - z)!");
        return false;
    }
    re = /[A-Z]/;
    if (!re.test(pswd)) {
        alert("Error: Password must contain at least one uppercase letter (A - Z)!");
        return false;
    }
    return true;
}

function valmob(mob) {
    var numbers = /^[0-9]+$/;
    if (mob.length == 10) {
        if (mob.match(numbers))
            return true;
        else {
            alert("Mobile Number should be in Number format only.");
            return false;
        }
    }
    else {
        alert("Invalid Mobile number");
        return false;
    }
}

function valemail(email) {
    var mformat = /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/;
    if (email.match(mformat)) {
        return true;
    }
    else {
        alert("Invalid E-mail ID");
        return false;
    }
}