<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" type="text/css" href="stylesheet1.css">
</head>
<?php
$connection = mysqli_connect('localhost:4306', 'root', '');
$select_db = mysqli_select_db($connection, 'ass6');
$age = $_GET['age'];
$wpm = $_GET['wpm'];
$query = "SELECT * FROM Employee WHERE ";
if (is_numeric($age))
    $query .= "age <= $age";
if (is_numeric($wpm))
    $query .= " AND salary <= $wpm";
$qry_result = mysqli_query($connection, $query) or die(mysql_error());
$display_string = "<table heigth='125%' border='2' width='90%' align='center' bgcolor='black'>";
$display_string .= "<tr align='center'><td colspan=4><span style='font-size: 200%;'>Output for Employee Table</span></td></tr>";
$display_string .= "<tr bgcolor='white'>";
$display_string .= "<th>Name</th>";
$display_string .= "<th>Age</th>";
$display_string .= "<th>Sex</th>";
$display_string .= "<th>Salary</th>";
$display_string .= "</tr>";
while ($row = mysqli_fetch_array($qry_result)) {
    $display_string .= "<tr align='center'>";
    $display_string .= "<td>$row[name]</td>";
    $display_string .= "<td>$row[age]</td>";
    $display_string .= "<td>$row[sex]</td>";
    $display_string .= "<td>$row[salary]</td>";
    $display_string .= "</tr>";
}
echo "<b>&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbspQuery:" . $query . "</b><br/></br>";
$display_string .= "</table>";
echo $display_string;
?>